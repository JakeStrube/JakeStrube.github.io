 /*
  * 
  * EGR 314
  * HMI Subsystem for team 204
  * By: Jake Strube
  * 
  * 
  * 
  * 
*/


//#include <stdbool.h>
//#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/timer/tmr1.h"
#include "mcc_generated_files/uart/eusart1.h"
#include "ssd1306.h"


uint16_t ms=0;
uint16_t ms2=0;
uint16_t sec=0;
uint16_t sec2=0;


// Callback function to increment the timer to have milliseconds and seconds and blink the LED every second
void timer_callback(void)
{
    ms++;
    ms2++;
    if (ms>1000) 
    {
        
        ms -= 1000;
        sec++;
        //IO_RD6_Toggle();
    }
//    if (ms2>500)
//    {
//        ms2 -= 500;
//        sec2++;
//    }
}

void eusart_callback(void)
{
//    ms++;
}
// Send the message function
uint8_t send_message(char * my_message){
    printf("%s",my_message);
    return 1;
}
        

#define BUFSIZE 16
#define MSGSIZE 64
#define TEAMSIZE 5
#define MSGTESTSIZE 64
#define MSGTESTCHAR 0

const char my_id='S';
const char broad='X';
const char team_ids[TEAMSIZE+1]="XADSW";
char buffer_in[BUFSIZE+1];
char message_in[MSGSIZE+1];
char message_out[MSGSIZE+1];
uint8_t spot = 1;
unsigned int viewmessages = 0;


//char stream_in[]="-----AZcb34567890YB-----------AZcd34567890YB--AZed34567890YB--AZdz34567890YB---AZed1234567890123456789012345678901234567890123456789012345678YB-";
//char read_char(void){
//    static int ii=0;
//    char c = stream_in[ii];
//    ii++;
//    if (ii>=(sizeof stream_in)-1)
//    {ii=0;}
//    return c;
//}

void fill_string(char * mystring,char value,unsigned int size){
    for (int ii=0;ii<size;ii++){
        mystring[ii]=value;
    }
}

unsigned int find_char(char * mystring, char value,unsigned int size){
    char c=0;
    for (int ii=0;ii<size;ii++){
        c= mystring[ii];
        //printf("%c,%c;",value,mystring[ii]);
        if (c==value){
            return 1;
        }
    }
    return 0;
}

void handle_message(unsigned int ii){
    message_in[ii-2]=0;
    printf("%sYB",message_in);
    if(viewmessages == 1){
    if (spot <= 6){
        ssd1306_string_pos(0,0,"Message: ");
        ssd1306_setpos(0,spot);
        ssd1306_string(&message_in);
        ssd1306_string("YB");
        spot = spot+1;
        if (spot > 6){
            spot = 1;
        }
    }
    }
}


int main(void)
{

    
    
    //char c=0;
    unsigned int buffer_ii=0;
    unsigned int buffer_last_ii = 0;
    unsigned int message_ii=0;
    unsigned int message_last_ii=0;
    buffer_in[BUFSIZE]=0;
    message_in[MSGSIZE]=0;
    unsigned int message_incoming=0;
    unsigned int message_me=0;
    unsigned int processing = 0;
    unsigned int processmessage = 0;
    unsigned int broadcast = 0;
    unsigned int message_0 = 0;
    unsigned int message_5 = 0;
    unsigned int message_6 = 0;
    unsigned int message_7 = 0;
    unsigned int message_8 = 0;
    unsigned int hex_5_1 = 0;
    unsigned int hex_5_2 = 0;
    unsigned int main_menu = 0;
    unsigned int set_speed = 0;
    unsigned int set_distance = 0;
    unsigned int other_options = 0;
    unsigned int message4 = 0;
    unsigned int message5 = 0;
    unsigned int turnoffsystem = 0;
    unsigned int turnoffsub = 0;
    unsigned int turnoffandrey = 0;
    unsigned int turnoffjacob = 0;
    unsigned int demo = 0;
    double newdistance = 0;
    double newspeed = 0;
    uint8_t currentspeed1 = 0;
    uint8_t currentdistance1 = 0;
    uint8_t setdistance1 = 0;
    char currentspeed[3];
    char distance[3];
    char setdistance[3];
    char c;
    char d;
    char e;
    char f;
    char g;
    char h;
    char i;
    char z;
    

    fill_string(buffer_in,'a',BUFSIZE);
    fill_string(message_in,'_',MSGSIZE);
    message_in[MSGTESTSIZE]=MSGTESTCHAR;
    
    // Sets my_id as a char so I can compare incoming messages
    char me;
    me = my_id;

    uint16_t ms_last=0;
    uint16_t sec_last=0;
    SYSTEM_Initialize();
    ADC_Initialize();
    ssd1306_init(0x3C);
    // If using interrupts in PIC18 High/Low Priority Mode you need to enable the Global High and Low Interrupts 
    // If using interrupts in PIC Mid-Range Compatibility Mode you need to enable the Global and Peripheral Interrupts 
    // Use the following macros to: 

    // Enable the Global Interrupts 
    INTERRUPT_GlobalInterruptEnable(); 

    // Disable the Global Interrupts 
    //INTERRUPT_GlobalInterruptDisable(); 

    // Enable the Peripheral Interrupts 
    INTERRUPT_PeripheralInterruptEnable(); 

    // Disable the Peripheral Interrupts 
    //INTERRUPT_PeripheralInterruptDisable(); 
    TMR1_Initialize();
    TMR1_Start();
    TMR1_TMRInterruptEnable();

    TMR1_OverflowCallbackRegister(timer_callback);

    EUSART1_Initialize();
    EUSART1_Enable();
//    EUSART1_TransmitEnable();
//    EUSART1_ReceiveEnable();
//    EUSART1_TransmitInterruptEnable();
//    EUSART1_ReceiveInterruptEnable();
//    
//    EUSART1_RxCompleteCallbackRegister(eusart_callback);
    
    ADC_ChannelSelect(ADC_CHANNEL_ANB1);
    ADC_ConversionStart();
        
        
//    printf("%lu", sizeof buffer_in);
    main_menu = 1;
    processing = 0;
    ssd1306_clear(); // Used to get rid of the noise when starting up the OLED screen
    while(1)
    {
        if (turnoffsystem == 0){
        ssd1306_string_pos(115,0,"On");
        }
        if(viewmessages == 0){
        if (sec >10){
            ssd1306_clear();
            sec -= 10;
        }
        }
        
        
        
        
        // Get ADC value from potentiometer and save it to a float that is rounded
        

//        ssd1306_setpos(0,5);
//        ssd1306_string(&ADC);
        
        
        
//        IO_RD6_SetHigh();
//        IO_RD5_SetHigh();
        
        if(EUSART1_IsRxReady())
        {
            //main_menu=0;
            c= EUSART1_Read(); // Read the incoming UART 
            buffer_in[buffer_ii]=c; // Set the UART character into the buffer
            // Checking for the start of a message
            if (buffer_in[buffer_last_ii]=='A' & buffer_in[buffer_ii]=='Z')
            {
                //ssd1306_clear();
                //main_menu=0;
                //ssd1306_string_pos(0,1,"Message start ");
                //printf("PIC: message start \n");
                fill_string(message_in,'_',MSGSIZE);
                message_in[MSGTESTSIZE]=MSGTESTCHAR;
                message_incoming=1;
                message_in[0] = buffer_in[buffer_last_ii];
                message_ii=1;
            }
            // Checking for the end of the message
            if (buffer_in[buffer_last_ii]=='Y' & buffer_in[buffer_ii]=='B')
            {
                //printf("PIC: message end \n");
                //ssd1306_string_pos(0,4,"Message end ");
                message_incoming=0;
                message_in[message_ii] = buffer_in[buffer_ii];
                message_last_ii= message_ii;
                message_ii = message_ii+1;
                //handle_message(message_ii);
                if (processing == 1)
                {
                    //ssd1306_string_pos(0,5,"Processing");
                    if (message_me == 1)
                    {
                        processmessage = 1;
                        //printf("Message for me \n");
                        //handle_message(message_ii);
                        message_me = 0;
                        processing = 0;
                        //ssd1306_string_pos(0,6,"For me");
                    }
                    else if(broadcast == 1)
                    {
                        //printf("Broadcasting \n");
                        processmessage = 1;
                        handle_message(message_ii);
                        broadcast = 0;
                        processing = 0;
                        //ssd1306_string_pos(0,6,"Broadcast");
                    }
                    else
                    {
                        //printf("Passing Message\n");
                        handle_message(message_ii);
                        //ssd1306_string_pos(0,6,"Passing");
                        processing = 0;
                        //main_menu=1;
                    }
                }
                else{
                    //printf("nothing else to do with this message\n");
                    //handle_message(message_ii);
                    message_ii=0; // Restarts the message buffer
                }
                //handle_message(message_ii);
                IO_RD5_Toggle();
            }
            if (message_incoming!=0){
                message_in[message_ii] = buffer_in[buffer_ii];
                //printf("AZSWPIC: Full Message: %s YB", message_in);

                // Checking the sender
                if (message_ii==2)
                {
                    unsigned result = 0;
                    char a=0;
                    a = message_in[message_ii];
                    result= find_char(team_ids,a,TEAMSIZE);
                    
                    // Sender is not in the team
                    if (result==0)
                    {
                        //printf("PIC: sender not in team deleting message \n");
                        //handle_message(message_ii);
                        //ssd1306_string_pos(0,2,"sender not t");
                        message_incoming = 0; // Set incoming message status to no message incoming
                        message_ii=0; // Restarts the message buffer
                        //return 0;
                    } 
                    // Sender is in team
                    else 
                    {
                        //printf("PIC: sender in team \n");
                        char me;
                        me = my_id;
                        // If i am the sender
                        if (me == a)
                        {
                            //printf("PIC: Sender is me deleting message \n");
                            //ssd1306_string_pos(0,2,"sender me");
                            message_incoming = 0; // Set incoming message status to no message incoming
                            message_ii=0; // Restarts the message buffer
                            ssd1306_clear();
                            //ssd1306_string_pos(0, 2, "sent by me");
                        }
                        // If i am not the sender
//                        else 
//                        {
//                            //printf("PIC: Sender not me \n");
//                            
//                        }
                        
                    }
                }
                
                // Checking the receiver
                if (message_ii==3)
                {
                    unsigned result = 0;
                    char b=0;
                    b = message_in[message_ii];
                    result= find_char(team_ids,b,TEAMSIZE);
                    message_me = 0;
                    broadcast = 0;
                    //printf(" RECIVER: %c \n",b);
                    
                    // Receiver is not in team
                    if (result==0){
                        //printf("PIC: receiver not in team deleting \n");
                        //ssd1306_string_pos(0,3,"recivever not in t");
                        message_incoming = 0; // Set incoming message status to no message incoming
                        message_ii=0; // Restarts the message buffer
                        processing = 0;
                    } 
                    // Receiver is in team
                    else {
                        //printf("PIC: receiver in team \n");
                        // Receiver is me
                        processing = 1;
                        //ssd1306_string_pos(0,6,"Reciever");
                        if (me == b){
                            message_me = 1;
                            //printf("PIC: receiver is me \n");
                            //ssd1306_string_pos(0,3,"for me");
                            //handle_message(message_ii);
                        }
                        else if (broad == b)
                        {
                            broadcast = 1;
                            //ssd1306_string_pos(0,3,"broadcast");
                           // printf("Receiver is broadcast \n");
                        }
                        // Receiver is not me
                        else{
                            //printf("PIC: receiver is not me \n");
                            //ssd1306_string_pos(0,3,"for someone else");
                        }
                    }
                }
                // Character 1
//                if (message_ii==4) 
//                {   char c=0;
//                    c=message_in[message_ii];
//                                printf("C: %c\n",c);}

                // Character 2
//                if (message_ii==5)
//                {   char d=0;
//                    d=message_in[message_ii];
//                    char z = d;
//                printf("D: %c\n",d);}
//                // Character 3
//                if (message_ii==6)
//                {   char e=0;
//                    e=message_in[message_ii];}
//                // Character 4
//                if (message_ii==7)
//                {   char f=0;
//                    f=message_in[message_ii];}
//                // Character 5
//                if (message_ii==8)
//                {   char g=0;
//                    g=message_in[message_ii];}
//                // Character 6
//                if (message_ii==9)
//                {   char h=0;
//                    h=message_in[message_ii];}
                 //Character 7
//                if (message_ii==10)
//                {   char i=0;
//                    i=message_in[message_ii];}
                
                
                
                
                
                
//                if (processmessage == 1){
//                    //printf("PIC: Message Processing \n");
//                    if (message_ii == 4){
//                        char i=0;
//                        i = message_in[message_ii];
//                        handle_message(message_ii);
//                        
//                        // If the message identifier is 0
//                        //printf(" MESSAGE IDENTIFIER: %c \n",i);
//                        
//                        if (i == '0'){ 
//                            printf("PIC: Processing incoming message 0 \n");
//                            ssd1306_clear();
//                            ssd1306_string_pos(0, 0, "Message Type 0");
//                            message_me = 0;
//                            processing = 0;
//                        }
//                        // If the message identifier is 5
//                        else if (i == '5'){
//                            //processing = 0;
//                            printf("PIC: Processing incoming message 5 \n");
//                            ssd1306_clear();
//                            ssd1306_string_pos(0, 0, "Message Type 5");
//                            handle_message(message_ii);
//                            //message_me = 0;
//                            message_5 = 1;
//                        }
//                        // If the message identifier is 6
//                        else if (i == '6'){
//                            printf("PIC: Processing incoming message 6 \n");
//                            ssd1306_clear();
//                            ssd1306_string_pos(0, 0, "Message Type 6");
//                            message_me = 0;
//                            processing = 0;
//                        }
//                        // If the message identifier is 7
//                        else if (i == '7'){
//                            printf("PIC: Processing incoming message 7 \n");
//                            ssd1306_clear();
//                            ssd1306_string_pos(0, 0, "Message Type 7");
//                            message_me = 0;
//                            processing = 0;
//                        }
//                        // If the message identifier is 8
//                        else if (i == '8'){
//                            printf("PIC: Processing incoming message 8 \n");
//                            ssd1306_clear();
//                            ssd1306_string_pos(0, 0, "Message Type 8");
//                            message_me = 0;
//                            processing = 0;
//                        }
//                        else{
//                            printf("PIC: Identifier not known \n");
//                            ssd1306_clear();
//                            ssd1306_string_pos(0, 0, "Message Type not available");
//                            message_me = 0;
//                            processing = 0;
//                        }
//                    }
//                }
//                
//                
//                if (message_5 == 1)
//                {
//                    if (message_ii == 5)
//                    {
//                        //printf("getting hex values \n");
//                        hex1 = message_in[message_ii];
//                        hex_5_1 = 1;
//                        
//                    }
//                    if (message_ii == 6)
//                    {
//                        hex2 = message_in[message_ii];
//                        hex_5_2 = 1;
//                    }
//                    
//                }
                
                
                
                message_last_ii= message_ii; // set the current message slot to the last message slot in the buffer
                message_ii = message_ii+1; // Increment the message in buffer to the next slot

                // Handling messages that are to long
                if (message_ii<MSGTESTSIZE){} else{
                    //printf("PIC: message too large. deleting \n");
                    message_incoming = 0; // Set incoming message status to no message incoming
                    message_ii=0; // Restarts the message buffer
                    //ssd1306_clear();
                    //ssd1306_string_pos(0, 0, "Message to big");
                    
                }
            }
            buffer_last_ii= buffer_ii;
            buffer_ii = (buffer_ii+1)%BUFSIZE;
        }
        
        
        
        
//        if (hex_5_1 == 1 && hex_5_2 == 1)
//        {
//            char hex_5_12[2];
//            
//            //printf("HEX: %c%c \n",hex1,hex2);
//            hex_5_12[0] = hex1;
//            hex_5_12[1] = hex2;
//            //printf("HEX Combined: %.2s \n",hex_5_12);
//            hex_5_1 = 0;
//            hex_5_2 = 0;
//            
//            
//            
//            //char hex_string = hex_5_12;
//            char *endptr;
//            uint8_t hex_value;
//            char hex;
//            // Use strtol to convert the hexadecimal string to an integer
//            hex_value = strtol(hex_5_12, &endptr, 16);
//            // Print the hexadecimal value
//            //printf("Hexadecimal value: %d \n", hex_value);
////            sprintf(&hex,"Hexadecimal value: %d", hex_value);
////            ssd1306_setpos(0,2);
////            ssd1306_string(&hex);
//            //handle_message(message_ii);
//            
//        }
//        
        else if (ms2 > 500)
        {
            
            ms2 -= 500;
            IO_RD6_Toggle();
            
            
            
        ADC_ChannelSelect(ADC_CHANNEL_ANB1);
        ADC_ConversionStart();
        
        while (!ADC_IsConversionDone());
        float adcValue = ADC_ConversionResultGet();
        adcValue = (adcValue/1023)*100;
        double adcValuerounded = roundf(adcValue);
        char *ADC;
        sprintf(&ADC,"%.1f",adcValuerounded);
        
        
        
        if(main_menu == 1){
//            if(IO_RA0_GetValue() == 1)
//            {
//                main_menu = 0;
//                ssd1306_clear();
//            }
            //IO_RD6_SetHigh();
            
            
            sprintf(currentspeed, "%3d",currentspeed1);
            
            ssd1306_string_pos(0, 0, "Main Menu");
            ssd1306_string_pos(0,1,"Green to select");
            ssd1306_string_pos(10, 2, "Set Speed"); // (X,Y, "String")
            ssd1306_string_pos(10, 3, "Set Distance");
            ssd1306_string_pos(10, 4, "Other Options");
            sprintf(distance, "%3d",currentdistance1);
            sprintf(setdistance,"%3d",setdistance1);
            
//            ssd1306_string_pos(0, 6, "Current Speed:");
//            ssd1306_setpos(85,6);
//            ssd1306_string(&currentspeed);
            ssd1306_string_pos(0, 5, "Set distance:");
            ssd1306_setpos(75,5);
            ssd1306_string(setdistance);        
            ssd1306_string_pos(0, 7, "Follow distance:");
            ssd1306_setpos(95,7);
            ssd1306_string(distance);
            ssd1306_string_pos(0, 6, "Current Speed:");
            ssd1306_setpos(85,6);
            ssd1306_string(currentspeed);
           
            if (adcValuerounded <= 33)
            {
                ssd1306_setpos(100,2);
                ssd1306_string("<");
                ssd1306_setpos(100,3);
                ssd1306_string(" ");
                ssd1306_setpos(100,4);
                ssd1306_string(" ");
                if (IO_RA6_GetValue()!=0)
                {
                    set_speed = 1;
                    main_menu=0;
                    ssd1306_clear();
                }
            }
            else if (adcValuerounded >= 34 && adcValuerounded <=65)
            {
                ssd1306_setpos(100,2);
                ssd1306_string(" ");
                ssd1306_setpos(100,3);
                ssd1306_string("<");
                ssd1306_setpos(100,4);
                ssd1306_string(" ");
                if (IO_RA6_GetValue()!=0)
                {
                    set_distance = 1;
                    main_menu=0;
                    ssd1306_clear();
                }
            }
            else if (adcValuerounded >= 66 && adcValuerounded <=100)
            {
                ssd1306_setpos(100,2);
                ssd1306_string(" ");
                ssd1306_setpos(100,3);
                ssd1306_string(" ");
                ssd1306_setpos(100,4);
                ssd1306_string("<");
                if (IO_RA6_GetValue()!=0)
                {
                    other_options = 1;
                    main_menu=0;
                    ssd1306_clear();
                }
            }
        }
        
        // Functions to adjust the set speed screen
        if(set_speed == 1)
        {
            newspeed = roundf(adcValue);
            // 0
            if (newspeed >=0 && newspeed<10 ) 
            {
                currentspeed1 = 0;
            }
            // 20
            else if (newspeed >=10 && newspeed<30 )
            {
                currentspeed1 = 20;
            }
            //40
            else if (newspeed >=30 && newspeed<50 )
            {
                currentspeed1 = 40;
            }
            //60
            else if (newspeed >=50 && newspeed<70 )
            {
                currentspeed1 = 60;
            }
            //80
            else if (newspeed >=70 && newspeed<90 )
            {
                currentspeed1 = 80;
            }
            //100
            else if (newspeed >=90 && newspeed<=100 )
            {
                currentspeed1 = 100;
            }
            sprintf(currentspeed, "%3d",currentspeed1);
            ssd1306_string_pos(0, 0, "Set Speed");
            ssd1306_string_pos(0, 2, "New speed:");
            ssd1306_setpos(60,2);
            ssd1306_string(currentspeed);
            ssd1306_string_pos(0, 4, "Push black to select");
            //printf("speedout: %1d\n",currentspeed1);
            if(IO_RA0_GetValue() == 1)
            {
                //__delay_ms(20);
                printf("AZSWMotorSpeed%dYB",currentspeed1);
                printf("AZSDMotorSpeed%dYB",currentspeed1);
                main_menu = 1;
                set_speed = 0;
                ssd1306_clear();
            }
        }
        
         //Functions to adjust the set distance screen
        if(set_distance == 1)
        {
            newdistance = roundf(adcValue);
            if (newdistance >=0 && newdistance<10 ) 
            {
                setdistance1 = 0;
            }
            // 20
            else if (newdistance >=10 && newdistance<30 )
            {
                setdistance1 = 20;
            }
            //40
            else if (newdistance >=30 && newdistance<50 )
            {
                setdistance1 = 40;
            }
            //60
            else if (newdistance >=50 && newdistance<70 )
            {
                setdistance1 = 60;
            }
            //80
            else if (newdistance >=70 && newdistance<90 )
            {
                setdistance1 = 80;
            }
            //100
            else if (newdistance >=90 && newdistance<=100 )
            {
                setdistance1 = 100;
            }
            sprintf(setdistance,"%d",setdistance1);
            ssd1306_string_pos(0, 0, "Set Distance");
            ssd1306_string_pos(0, 2, "New distance:");
            ssd1306_setpos(85,2);
            ssd1306_string(setdistance);
            ssd1306_string_pos(0, 4, "Push black to select");
            char hex[3];
            sprintf(hex,"%02X",(uint8_t)setdistance1);
            //sprintf(&distance,"%.1f",adcValuerounded);
            if(IO_RA0_GetValue() == 1)
            {
                main_menu = 1;
                set_distance = 0;
                ssd1306_clear();
                printf("AZSDSensorDistance%dYB",setdistance1);
                printf("AZSA2%sYB",hex);
                
            }
        }
        
        if (other_options == 1)
        {
            ssd1306_string_pos(0, 0, "Other Options");
            ssd1306_string_pos(0,1,"Green to select");
            ssd1306_string_pos(10, 2, "Turn off system"); // (X,Y, "String")
            ssd1306_string_pos(10, 3, "Exhibit Mode");
            //ssd1306_string_pos(10, 3, "Turn off subsys");
            ssd1306_string_pos(10, 4, "View messages");
            ssd1306_string_pos(10, 5, "Main Menu");
            
            
            if (adcValuerounded <= 25)
            {
                ssd1306_setpos(100,2);
                ssd1306_string("<");
                ssd1306_setpos(100,3);
                ssd1306_string(" ");
                ssd1306_setpos(100,4);
                ssd1306_string(" ");
                ssd1306_setpos(100,5);
                ssd1306_string(" ");
                if (IO_RA6_GetValue()!=0)
                {
                    turnoffsystem = 1;
                    other_options=0;
                    ssd1306_clear();
                }
            }
            else if (adcValuerounded >= 26 && adcValuerounded <=50)
            {
                ssd1306_setpos(100,2);
                ssd1306_string(" ");
                ssd1306_setpos(100,3);
                ssd1306_string("<");
                ssd1306_setpos(100,4);
                ssd1306_string(" ");
                ssd1306_setpos(100,5);
                ssd1306_string(" ");
                if (IO_RA6_GetValue()!=0)
                {
                    demo = 1;
                    other_options = 0;
                    ssd1306_clear();
                }
            }
            else if (adcValuerounded >= 51 && adcValuerounded <=75)
            {
                ssd1306_setpos(100,2);
                ssd1306_string(" ");
                ssd1306_setpos(100,3);
                ssd1306_string(" ");
                ssd1306_setpos(100,4);
                ssd1306_string("<");
                ssd1306_setpos(100,5);
                ssd1306_string(" ");
                if (IO_RA6_GetValue()!=0)
                {
                    viewmessages = 1;
                    other_options = 0;
                    ssd1306_clear();
                }
            }
            else if (adcValuerounded >= 76 && adcValuerounded <=100)
            {
                ssd1306_setpos(100,2);
                ssd1306_string(" ");
                ssd1306_setpos(100,3);
                ssd1306_string(" ");
                ssd1306_setpos(100,4);
                ssd1306_string(" ");
                ssd1306_setpos(100,5);
                ssd1306_string("<");
                if (IO_RA6_GetValue()!=0)
                {
                    main_menu=1;
                    other_options = 0;
                    ssd1306_clear();
                }
            }
        }
        
        if (turnoffsystem == 1){
            ssd1306_string_pos(0, 7, "press black for on");
            ssd1306_string_pos(110, 0, "off");
            if (IO_RA0_GetValue()!=0)
                {
                    turnoffsystem = 0;
                    main_menu = 1;
                    ssd1306_clear();
                }
            
        }
        
        if(turnoffsub == 1){
            ssd1306_string_pos(0, 0, "Turn off subsystem");
            ssd1306_string_pos(0,1,"Black to select");
            ssd1306_string_pos(10, 2, "Turn off Sensor"); // (X,Y, "String")
            ssd1306_string_pos(10, 3, "Turn off Motor");
            
            
            if (adcValuerounded <= 50)
            {
                ssd1306_setpos(100,2);
                ssd1306_string("<");
                ssd1306_setpos(100,3);
                ssd1306_string(" ");
                if (IO_RA6_GetValue()!=0)
                {
                    turnoffandrey = 1;
                    other_options=0;
                    ssd1306_clear();
                }
            }
            else if (adcValuerounded >= 26 && adcValuerounded <=50)
            {
                ssd1306_setpos(100,2);
                ssd1306_string(" ");
                ssd1306_setpos(100,3);
                ssd1306_string("<");
                if (IO_RA6_GetValue()!=0)
                {
                    turnoffjacob = 1;
                    other_options = 0;
                    ssd1306_clear();
                }
            }
        }
        
        
        if(viewmessages == 1){
            ssd1306_string_pos(0, 7, "black to go back");
            if (IO_RA0_GetValue()!=0)
                {
                    viewmessages = 0;
                    main_menu = 1;
                    ssd1306_clear();
                }
        }
        
        //end of time loop
        }
        
    
        
        
        if (processmessage ==1)
        {
            IO_RD6_Toggle();
//            ssd1306_clear();
//            ssd1306_string_pos(0, 0, "Processing");
//            ssd1306_setpos(0,5);
//            ssd1306_string(&message_in);
//            ssd1306_setpos(0,1);
//            ssd1306_string(&c);
            c = message_in[4];
            //printf("CP: %c\n",c);

            if(c == '4'){
                //ssd1306_string_pos(0, 1, "Message 4");
                
                message4 = 1;
                processmessage = 0;
//                main_menu=1;
            }
            else if(c == '5'){
                //ssd1306_string_pos(0, 1, "Message 5");
                
                message5 = 1;
                processmessage = 0;
//                main_menu=1;
            }
            else{
                //ssd1306_string_pos(0, 2, "Invalid Message");
                processmessage = 0;
//                main_menu=1;
                //ssd1306_clear();
            }
        }
        
        
        if (demo == 1){
            sprintf(distance, "%3d",currentdistance1);
            ssd1306_string_pos(0, 7, "Black for main menu");  
            ssd1306_string_pos(0, 0, "Demonstration");
            ssd1306_string_pos(0, 2, "Distance:");
            ssd1306_setpos(55,2);
            ssd1306_string(distance);
            ssd1306_string_pos(0, 4, "Current Speed:");
            ssd1306_setpos(90,4);
            ssd1306_string(currentspeed);
            
            if (IO_RA0_GetValue()!=0)
                {
                    demo = 0;
                    main_menu = 1;
                    ssd1306_clear();
                }
        }
        
        if (message4 == 1 || message5 ==1){
            d = message_in[5];
            e = message_in[6];
            
//            printf("DP: %c\n",d);
//            printf("EP: %c\n",e);
            char messagehex[2];
            messagehex[0] = d;
            messagehex[1] = e;
            //printf("MESSAGEHEX: %s",messagehex);
            
            char *endptr;
            long hex_value;
            char hex;
            // Use strtol to convert the hexadecimal string to an integer
            hex_value = strtol(messagehex, &endptr, 16);
            if (hex_value > 100){
                hex_value = 100;
            }
//            sprintf(&hex,"Hexadecimal value: %1d", hex_value);
            //printf("HEX: %1d",hex_value);
//            ssd1306_setpos(50,5);
//            ssd1306_string(&hex);
            if (message4 == 1){
                currentspeed1 = (uint8_t)hex_value;
                //printf("speedin: %d\n",currentspeed1);
                message4 = 0;
//                main_menu=1;
                //ssd1306_clear();
            }
            if (message5 == 1){
                currentdistance1 = (uint8_t)hex_value;
                message5 = 0;
                //ssd1306_string_pos(120, 7, "R");
//                printf("AZSXgotmessageYB");
//                main_menu=1;
                //ssd1306_clear();
            }
            
            
            
        }
//        if (message5 == 1){
//            
//        }
        // Message Identifier byte

        
//        if ((sec%3==0) & (sec!=sec_last)){
//            sprintf(message_out,"AZbaPIC: Heartbeat %u YB",sec);
//            send_message(message_out);
////            printf("AZbaPIC: Heartbeat %u YB",sec);
//        }
        
        if (IO_RE2_GetValue()!=0)
        {return 1;}
        
//        if (IO_RA0_GetValue()!=0)
//        {printf("AZWShello!YB");
//                ssd1306_string_pos(0, 1, "This is a test");
//                        __delay_ms(500);
//        }
//        
//        if(IO_RE2_GetValue() == 1)
//            {
//                main_menu = 1;
//                ssd1306_clear();
//            }
//        
        // Activate the OLED screen on the RED button
        // For position
//        if (IO_RE2_GetValue() == 1)
//        {
//            IO_RD6_Toggle();
//            ssd1306_clear();
//            ssd1306_setscale(0);
//            ssd1306_string_pos(0, 0, "This is a test");
//            ssd1306_setscale(0);
//            ssd1306_string_pos(10, 2, "10, 2"); // (X,Y, "String")
//            ssd1306_string_pos(6, 7, "6, 7");
//        }
//        if(IO_RA0_GetValue()==1)
//        {
//            IO_RD5_Toggle();
//            ssd1306_clear();
//            ssd1306_setscale(0);
//            ssd1306_string_pos(0,0,"Test screen 2");
//            ssd1306_string_pos(123,7,"!"); // Furthest it can go without moving to the top again
//            
//           
//            
//            //Invert color every second
////            ssd1306_invert(1);
////            __delay_ms(1000);
////            ssd1306_invert(0);
//        }
       
//        if (IO_RE2_GetValue()==0)
//        {IO_RD6_SetLow();}
//        if (IO_RE2_GetValue()==1)
//        {IO_RD6_SetHigh();}
//        if (IO_RA7_GetValue()==1)
//        {IO_RD5_SetHigh();}
        
//        if (IO_RA0_GetValue()!=0)
//        {
//            printf("AZSWMotorSpeed%dYB",currentspeed1);
//            __delay_ms(1000);
//        }
        
        

//        sprintf(&ADC,"%.1f",adcValuerounded);
//        ssd1306_setpos(0,5);
//        ssd1306_string(&ADC);
        
        
//        if (0 < adcValue < 10){
//            IO_RD6_Toggle();
//            __delay_ms(1000);
//        }
//        if(adcValue > 10){
//            IO_RD6_SetLow();
//        }
        
        sec_last = sec;
        ms_last = ms;
        
    }
}


// EXAMPLES


// Reset button

//        if (IO_RA6_GetValue()!=0)
//        {return 1;}

// Converting to hex and putting it on the OLEd screen

//            char hex_string[] = "2A";
//            char *endptr;
//            uint8_t hex_value;
//            char hex;
//            // Use strtol to convert the hexadecimal string to an integer
//            hex_value = strtol(hex_string, &endptr, 16);
//            // Print the hexadecimal value
//            printf("Hexadecimal value: %d \n", hex_value);
//            sprintf(&hex,"Hexadecimal value: %d", hex_value);
//            ssd1306_setpos(0,2);
//            ssd1306_string(&hex);



// Getting ADC value to be 0-100 and display on OLED

//        ADC_ConversionStart();
//        
//        while (!ADC_IsConversionDone());
//        
//        float adcValue = ADC_ConversionResultGet();
//        
//        adcValue = (adcValue/1023)*100;
//        double adcValuerounded = roundf(adcValue);
//        
//        char ADC;
//        sprintf(&ADC,"%.1f",adcValuerounded);
//        ssd1306_setpos(0,5);
//        ssd1306_string(&ADC);




// To print to jakes system

//  printf(AZSWMotorSpeed100YB)
//  set for between 0, 20, 40, 60, 80, 100
// set if ADC value is between those values to round to each variable
                        





//printf("AZAS50EYB");